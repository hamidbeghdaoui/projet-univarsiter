This project was bootstrapped with [Create React App](https://github.com/facebookincubator/create-react-app).

You can find the full README [here](https://github.com/facebookincubator/create-react-app/blob/master/template/README.md).
